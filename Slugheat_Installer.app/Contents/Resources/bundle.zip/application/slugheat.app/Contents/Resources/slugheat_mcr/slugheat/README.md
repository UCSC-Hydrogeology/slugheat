# slugheat
working repo for processing software for data collected by a heat-flow measurement system
